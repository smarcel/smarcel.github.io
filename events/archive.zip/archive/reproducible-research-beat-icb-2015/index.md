---
title: "Reproducible Research in Biometrics: moving to the BEAT"
date: '2015-06-01'

event_name: IEEE International Conference on Biometrics (ICB)

location: In-Person
address:
  street: ''
  city: ''
  region: ''
  country: ''

authors:
  - me

tags:
  - Keynote
  - Academic

featured: false
---
