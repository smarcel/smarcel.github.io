---
title: "Spoofing and Anti-Spoofing in Biometrics"
date: '2020-02-01'

event_name: First Israeli Biometrics Winter School

location: In-Person
address:
  street: ''
  city: ''
  region: ''
  country: Israel

authors:
  - me

tags:
  - Academic

featured: false
---
