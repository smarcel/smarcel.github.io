---
title: "Spoofing and Anti-Spoofing in Biometrics: lessons learned from the TABULA RASA project"
date: '2013-09-29'

event_name: IEEE International Conference on Biometrics: Theory, Applications and Systems (BTAS)

location: In-Person
address:
  street: ''
  city: ''
  region: ''
  country: ''

authors:
  - me

tags:
  - Academic

featured: false
---
