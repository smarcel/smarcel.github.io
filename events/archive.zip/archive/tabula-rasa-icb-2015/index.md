---
title: "Spoofing and Anti-Spoofing in Biometrics: lessons learned from the TABULA RASA project"
date: '2015-06-01'

event_name: IEEE International Conference on Biometrics (ICB)

location: In-Person
address:
  street: ''
  city: ''
  region: ''
  country: ''

authors:
  - me

tags:
  - Academic

featured: false
---
