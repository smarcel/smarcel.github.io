---
title: "Introduction to biometrics and anti-spoofing"
date: '2022-02-10'

event_name: Université de Lausanne, 4e Rencontre entre la Science et le Droit dans le Numérique – Place à la biométrie !
event_url: https://wp.unil.ch/digiweek-fdca/editions-precedentes/colloque-2022/

location: In-Person
address:
  street: Bâtiment Anthropole, Salle 1129
  city: Lausanne
  region: VD
  country: Switzerland

authors:
  - me

tags:
  - Academic

featured: false
---
