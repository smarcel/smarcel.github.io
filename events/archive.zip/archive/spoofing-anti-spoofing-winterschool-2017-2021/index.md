---
title: "Spoofing and Anti-Spoofing in Biometrics"
date: '2021-01-01'

event_name: IEEE Winter School on Security and Privacy in Biometrics

location: In-Person
address:
  street: ''
  city: ''
  region: ''
  country: ''

authors:
  - me

tags:
  - Academic

featured: false
---
