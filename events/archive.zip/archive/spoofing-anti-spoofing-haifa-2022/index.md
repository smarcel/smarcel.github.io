---
title: "Spoofing and Anti-Spoofing in Biometrics"
date: '2022-03-01'

event_name: University of Haifa seminar

location: In-Person
address:
  street: ''
  city: Haifa
  region: ''
  country: Israel

authors:
  - me

tags:
  - Academic

featured: false
---
