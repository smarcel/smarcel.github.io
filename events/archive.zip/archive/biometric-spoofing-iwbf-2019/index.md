---
title: "Biometric Spoofing and Anti-Spoofing"
date: '2019-05-01'

event_name: IEEE/IAPR International Workshop on Biometrics and Forensics

location: In-Person
address:
  street: ''
  city: ''
  region: ''
  country: ''

authors:
  - me

tags:
  - Keynote
  - Academic

featured: false
---
