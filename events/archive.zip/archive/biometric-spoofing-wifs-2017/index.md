---
title: "Biometric Spoofing and Anti-Spoofing"
date: '2017-12-01'

event_name: IEEE International Workshop on Information Forensics and Security

location: In-Person
address:
  street: ''
  city: ''
  region: ''
  country: ''

authors:
  - me

tags:
  - Academic

featured: false
---
