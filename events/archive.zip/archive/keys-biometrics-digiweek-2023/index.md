---
title: "Some keys to understand biometrics"
date: '2023-02-01'

event_name: Université de Lausanne, La semaine de la digitalisation
event_url: https://wp.unil.ch/digiweek-fdca/

location: In-Person
address:
  street: ''
  city: Lausanne
  region: VD
  country: Switzerland

authors:
  - me

tags:
  - Academic

featured: false
---
