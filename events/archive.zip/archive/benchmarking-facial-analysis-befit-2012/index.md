---
title: "On the importance of benchmarking in facial image analysis"
date: '2012-10-01'

event_name: IEEE ECCV International Workshop on Benchmarking Facial Image Analysis Technologies (BeFIT 2012)

location: In-Person
address:
  street: ''
  city: Florence
  region: ''
  country: Italy

authors:
  - me

tags:
  - Keynote
  - Academic

featured: false
---
