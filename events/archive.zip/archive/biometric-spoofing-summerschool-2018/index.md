---
title: "Biometric Spoofing and Anti-Spoofing"
date: '2018-06-01'

event_name: IEEE Summer School on Biometrics

location: In-Person
address:
  street: ''
  city: ''
  region: ''
  country: ''

authors:
  - me

tags:
  - Academic

featured: false
---
