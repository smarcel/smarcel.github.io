---
title: "Torchvision: the machine-vision package of Torch"
date: '2010-10-01'

event_name: ACM Multimedia

location: In-Person
address:
  street: ''
  city: ''
  region: ''
  country: ''

authors:
  - me

tags:
  - Academic

featured: false
---
