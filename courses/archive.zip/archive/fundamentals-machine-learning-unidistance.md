---
title: "Fundamentals in Machine Learning 1 & 2 (Master AI, UniDistance)"
summary: "Contributions to core machine learning teaching in the Idiap / UniDistance Master in Artificial Intelligence."
date: 2019-01-01
draft: false
tags:
  - Machine Learning
  - UniDistance
  - Master AI
  - Distance Learning
---

Within the **Idiap / UniDistance Master in Artificial Intelligence**, I contributed to the teaching of the courses **Fundamentals in Machine Learning 1** and **Fundamentals in Machine Learning 2**.

These courses formed part of the core machine learning curriculum of the program and were developed for a distance-learning format combining lectures, labs, and online teaching resources. The materials were adapted to a fully online educational model using **Moodle**, **virtual classes**, recorded content, and **JupyterHub-based labs**.

This teaching activity complemented my more specialized biometrics teaching by helping students build a stronger foundation in machine learning methods.
