---
title: "Biometrics (Master AI, UniDistance)"
summary: "Distance-learning Master AI course on biometrics, created for a dual-track program combining academic training and work in industry."
date: 2020-01-01
draft: false
tags:
  - Biometrics
  - UniDistance
  - Master AI
  - Distance Learning
---

This course was taught within the **Idiap / UniDistance Master in Artificial Intelligence**, a full-time dual-track program combining academic coursework with work in a company.

The Biometrics module introduced core concepts in biometric recognition and privacy-aware identity technologies in a format adapted to distance learning. Course materials and labs were designed for online delivery using platforms such as **Moodle**, **virtual classes**, **screencasts**, and later **JupyterHub**.

The course contributed to making advanced biometrics education accessible in a flexible and practice-oriented setting.
