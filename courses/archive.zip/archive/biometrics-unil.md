---
title: "Biometrics"
summary: "Yearly MSc course at the University of Lausanne on biometric person recognition, forensic biometrics, cybersecurity, and behavioral biometrics."
date: 2018-01-01
draft: false
tags:
  - Biometrics
  - Forensic Science
  - UNIL
  - Teaching
---

This yearly Master’s course is taught at the **University of Lausanne (UNIL)** in the Faculty of Law, Criminal Justice and Public Administration, within the **MSc in Forensic Science**.

The course introduces the analysis, modeling, and interpretation of biometric data for **biometric person recognition**, **forensic biometrics**, **cybersecurity**, and **behavioral biometrics in human-machine communication**. Over time, the course has been enriched with hands-on labs, including face analysis, speaker analysis, and spoofing-related exercises.

A major objective of the course is to make biometrics understandable and operational for students coming from forensic science backgrounds, while maintaining scientific rigor and practical relevance.

