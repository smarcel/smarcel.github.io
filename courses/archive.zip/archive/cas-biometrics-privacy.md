---
title: "CAS Biometrics and Privacy"
summary: "Certificate of Advanced Studies program on biometrics and privacy, designed for citizens, decision-makers, and authorities."
date: 2017-01-01
draft: false
tags:
  - Biometrics
  - Privacy
  - UniDistance
  - Continuing Education
---

From 2017 to 2019, I served as the **scientific head** of the Certificate of Advanced Studies (CAS) program in **Biometrics and Privacy** at UniDistance.

The program was designed to help **citizens**, **decision-makers**, and **public authorities** better understand biometric technologies, privacy issues, and data protection. In addition to coordinating the program, I taught the module **“Biometrics: Introduction and Applications.”**

This activity reflects a broader commitment to education beyond traditional degree programs, connecting technical biometrics knowledge with public understanding and societal impact.
