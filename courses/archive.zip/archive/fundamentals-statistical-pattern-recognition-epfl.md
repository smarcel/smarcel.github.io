---
title: "Fundamentals in Statistical Pattern Recognition (EE-612)"
summary: "EPFL doctoral course on the foundations of statistical pattern recognition and machine learning, combining theory with hands-on Python labs."
date: 2013-01-01
draft: false
tags:
  - Machine Learning
  - Pattern Recognition
  - EPFL
  - Doctoral Teaching
---

This EPFL doctoral course provides an in-depth introduction to the **fundamental algorithms of statistical pattern recognition**, ranging from regression and classification to probability distribution modeling.

The course was designed as a prerequisite for more advanced machine learning courses at EPFL. It emphasizes both conceptual understanding and practical implementation through **guided Python labs**, with course materials evolving over time to include topics such as regularization, support vector machines, hidden Markov models, decision trees, t-SNE, and deep learning.

A central pedagogical feature of the course is the combination of mathematical foundations with concrete implementation tools, including hands-on labs using **Bob**, **PyTorch**, and **JupyterHub**.

